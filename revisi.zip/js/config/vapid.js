export const VAPID_CONFIG = {
  publicKey: 'BMG9d9V5_ukjSnHhMPKUU9gsm8j5STN_sD5Rr5dIQztdCbjQ0Zeiket014ZjFh4SaUVg4aEKpJzFxA6ZosjmtzY',
  privateKey: 'K2q81vAFKEnPhrORv52oN-dd9E2TFOklYwEOUIU-OPU'
};