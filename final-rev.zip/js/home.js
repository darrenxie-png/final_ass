import L from 'leaflet';
import 'leaflet/dist/leaflet.css'; // pastikan CSS bawaan Leaflet ikut di-load

const Home = {
  async render() {
    return `
      <section class="home-section">
        <h2 class="page-title">📍 Daftar Story</h2>
        <div id="map" class="map-container"></div>
        <div id="stories" class="story-list"></div>
      </section>
    `;
  },

  async afterRender() {
    const token = localStorage.getItem('token');
    
    // Redirect if no token
    if (!token) {
      window.location.hash = '/login';
      return;
    }

    const storyList = document.getElementById('stories');

    // Reset map container
    const mapContainer = L.DomUtil.get('map');
    if (mapContainer != null) {
      mapContainer._leaflet_id = null;
    }

    // Initialize map
    const map = L.map('map').setView([-2.5, 118], 5);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    try {
      const response = await fetch('https://story-api.dicoding.dev/v1/stories?size=30', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch stories');
      }

      const result = await response.json();

      if (result.listStory && result.listStory.length > 0) {
        storyList.innerHTML = '';
        
        result.listStory.forEach((story) => {
          // Add story card
          storyList.innerHTML += `
            <article class="story-card">
              <img src="${story.photoUrl}" alt="Story from ${story.name}" class="story-img" />
              <div class="story-info">
                <h3>${story.name}</h3>
                <p>${story.description}</p>
                ${story.lat && story.lon ? `<p class="location">📍 ${story.lat}, ${story.lon}</p>` : ''}
              </div>
            </article>
          `;

          // Add marker if location exists
          if (story.lat && story.lon) {
            const lat = parseFloat(story.lat);
            const lon = parseFloat(story.lon);
            
            if (!isNaN(lat) && !isNaN(lon)) {
              const marker = L.marker([lat, lon])
                .addTo(map)
                .bindPopup(`
                  <div class="popup-content">
                    <h4>${story.name}</h4>
                    <img src="${story.photoUrl}" alt="Story thumbnail" style="width:100%;max-width:200px;margin:5px 0">
                    <p>${story.description}</p>
                  </div>
                `);
            }
          }
        });
      } else {
        storyList.innerHTML = '<p class="no-stories">Tidak ada story ditemukan.</p>';
      }
    } catch (error) {
      console.error('Error:', error);
      storyList.innerHTML = `<p class="error-message">Error: ${error.message}</p>`;
    }
  },
};

export default Home;
