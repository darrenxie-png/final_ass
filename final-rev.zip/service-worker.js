// service-worker.js
const CACHE_NAME = 'webgis-story-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/style.css',
  '/js/router.js',
  '/js/main.js',
  '/js/add.js',
  '/js/login.js',
  '/js/register.js',
  '/js/home.js',
  '/manifest.json',
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
];

// Install SW & cache files
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('Service Worker: Menyimpan cache');
      return cache.addAll(urlsToCache);
    })
  );
});

// Activate SW & hapus cache lama
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) =>
      Promise.all(
        cacheNames.map((name) => {
          if (name !== CACHE_NAME) {
            console.log('Service Worker: Menghapus cache lama', name);
            return caches.delete(name);
          }
        })
      )
    )
  );
});

// Fetch request
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      return (
        response ||
        fetch(event.request).catch(() =>
          new Response('Offline Mode: Data tidak tersedia.', {
            headers: { 'Content-Type': 'text/plain' },
          })
        )
      );
    })
  );
});
